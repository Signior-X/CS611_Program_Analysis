class A {
    A f1, f2;
    int f3;

    public static void main(String args[]) {
        A obj1 = new A();
        A obj2 = new A();
        obj1.foo(obj1, obj2);
        obj1.f1 = obj2;
    }

    void foo(A p1, A p2) {
        A obj3 = new A();
        p1.f1 = obj3;
        p1.f1.f3 = 10;
        p2.f3 = 20;
        obj3.bar(p2.f3, p2);
    }

    void bar(int p3, A p4) {
        A obj4 = new A();
        A obj5 = new A();
        A obj6 = new A();

        p4.f1 = obj4;
        p4.f1.f1 = obj5;
        p4.f1.f1.f3 = p3;

        p4.f1.f1.f1 = fun(obj6);
    }

    A fun(A obj1) {
        A obj2 = new A();
        A obj3 = new A();
        A obj4 = new A();
        A obj5 = new A();

        obj1.f1 = obj2;
        obj1.f1.f1 = obj3;
        obj1.f1.f1.f1 = obj4;
        obj1.f1.f1.f1.f1 = obj5;
        obj1.f1.f1.f1.f1.f3 = 10;

        return obj1;
    }
}